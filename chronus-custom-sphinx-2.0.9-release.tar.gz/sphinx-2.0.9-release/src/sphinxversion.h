#define SPH_SVN_TAG "release"
#define SPH_SVN_REV 4115
#define SPH_SVN_REVSTR "4115"
#define SPH_SVN_TAGREV "rel20-r4115"
#define SPHINX_TAG "-release"